/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejerciciopuente;

import java.util.concurrent.Semaphore;
import static javax.swing.text.html.HTML.Tag.S;

/**
 *
 * @author distribuidos
 */
public class Puente {
   
   
    Semaphore mutex;   
    Semaphore acceso; 
    Semaphore numCantCarro;    
    int cantCarros;
    
    
    public Puente(){
        
        cantCarros=0;
        numCantCarro=new Semaphore(10);
        mutex = new Semaphore(1, true);        
        acceso=new Semaphore(1);        
    }  
    
    public void darPasoIzqda() throws InterruptedException {
       
        numCantCarro.release();
        mutex.acquire();
        cantCarros+=1;
        if(cantCarros==1){  
        acceso.acquire(); 
        }
        mutex.release();        
        
        
    }

    public void terminarPasoIzqda() throws InterruptedException {
        mutex.acquire();         
        cantCarros-=1;
        if(cantCarros==0){
            acceso.release();
        }
        mutex.release();     
        numCantCarro.acquire();
        }
    
    public void darPasoDcha() throws InterruptedException {
        numCantCarro.release();
         mutex.acquire();
         cantCarros+=1;
        if(cantCarros==1){
            acceso.acquire();
        }
        mutex.release();
        
    }

    public void terminarPasoDcha() throws InterruptedException {
        
        mutex.acquire();         
        cantCarros-=1;
        if(cantCarros==0){
            acceso.release();
        }
        mutex.release();     
       numCantCarro.acquire();
    }
    
}

